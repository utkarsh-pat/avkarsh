# Master Specification Traceability

| Master-spec area | M0 authority | Implementation milestone |
|---|---|---|
| Product priorities/non-negotiables | `00-master-plan.md` | All |
| Organization/multi-property model | ADR-001, `03-data-model.md` | M1 |
| Multiple roles/limits | ADR-002, `04-permissions-matrix.md` | M1 |
| Owner onboarding/invitations | `05-mobile-information-architecture.md` | M1 |
| Room/bed availability | ADR-003, `03-data-model.md` | M2 |
| Reservations/rates | `03-data-model.md`, `12-core-screen-blueprints.md` | M2 |
| Guests/KYC/stays | `02-system-architecture.md`, threat model | M3 |
| Payments/invoices/expenses/cash | ADR-008, permission matrix | M3 |
| Guest QR/security | mobile IA, threat model | M4 |
| Housekeeping/maintenance/offline | ADR-006, mobile IA | M4 |
| WhatsApp bot/inbox/webhooks | ADR-005, system architecture | M5 |
| Concierge/services/commissions | data model, permission matrix | M6 |
| SaaS billing/platform admin | data model, permission matrix | M7 |
| Mobile targets/design rules | mobile IA, screen blueprints | M1–M7 |
| Supabase/RLS/storage | data model, threat model, source verification | M1–M7 |
| Testing/adversarial cases | `07-test-and-acceptance-plan.md` | All |
| Observability/backup/operations | system architecture, roadmap | M1–M7 |
| Repository structure | `06-repository-plan.md` | M1 foundation |
| Production checklist | acceptance plan, risk register | M7 |

## Coverage disposition

- **Covered in M0:** architecture, data, permissions, functional IA/blueprints, threat model, repository/CI plan, risks and milestone acceptance.
- **Intentionally deferred:** selected visual design, executable migrations, package scaffold, live integrations, provider accounts, pricing, legal/tax/retention decisions and production runbook details that require an implemented system.
- **Not silently omitted:** every deferred item is linked to an open decision or milestone gate.

## M0 audit result

The documentation covers the requested M0 artifacts and all master-spec product domains at planning level. It does not claim implementation evidence. M1 must copy approved documents into the repository and update them to reflect actual code/migrations rather than allowing planning documents to drift.

