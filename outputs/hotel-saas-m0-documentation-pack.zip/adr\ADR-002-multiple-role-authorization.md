# ADR-002: Multiple-Role Scoped Authorization

Status: Proposed  
Date: 2026-08-10

## Context

A person may simultaneously be owner, manager or accountant at different scopes. Financial actions also require limits and stronger authentication.

## Decision

Model reusable permission keys, role bundles and many-to-many membership role assignments at organization/property scope. Role allows combine; explicit deny wins at equal/narrower scope. Typed limits constrain discounts, refunds, expenses and cash adjustments. Actor mode (Google session, shared-device PIN, guest) imposes a hard ceiling.

## Consequences

Permission evaluation is more complex than a single role column but accurately represents the product. The resolver must be deterministic, testable and used consistently by server code and RLS helpers.

## Rejected alternatives

- One role on `users`: cannot represent multiple organizations/roles.
- Authorization in editable JWT user metadata: stale and user-controlled.
- UI-only route hiding: not authorization.

## Acceptance

Role-union, explicit-deny, property-scope, approval-limit, revoked-membership and shared-device-ceiling tests pass for every permission family.

