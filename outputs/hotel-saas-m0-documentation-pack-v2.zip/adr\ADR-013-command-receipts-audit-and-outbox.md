# ADR-013: Command Receipts, Transaction-Bound Audit and Outbox

Status: Proposed  
Date: 2026-08-10

## Decision

Use scoped `command_receipts` with operation, idempotency key, canonical request hash, status, safe result/response and expiry. Same key/hash returns the original result; same key/different hash returns conflict.

Critical audit events commit in the same transaction as the business mutation and use approved safe summaries. External notifications and retryable integration work use `outbox_events`; audit never depends on an outbox worker.

## Acceptance

Concurrent/retried commands are safe, changed-payload reuse conflicts, mutation rolls back if required audit insert fails, and outbox failure leaves the committed mutation/audit intact and observable.

