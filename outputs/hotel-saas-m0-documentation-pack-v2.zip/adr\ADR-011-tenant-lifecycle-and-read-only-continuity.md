# ADR-011: Tenant Lifecycle and Read-Only Continuity

Status: Proposed pending O-23 approval  
Date: 2026-08-10

## Decision

Lifecycle: `trial → active → past_due → grace → read_only → suspended → export_pending → closed → deletion_pending`, with reviewed recovery transitions.

In `read_only`: existing checkout, existing folio reconciliation, approved refund/reversal, owner export and emergency/public QR remain available; new booking is blocked; new check-in requires explicit grace configuration; configuration/member changes are blocked.

## Rationale

Commercial enforcement must not strand current guests, prevent financial correction or hold tenant data hostage. Lifecycle entitlement may restrict authorization but exposes only documented continuity/recovery exceptions.

## Acceptance

Every state/transition and exception is server/RLS tested. Owners retain export access. Lifecycle transition and exception use are audited.

